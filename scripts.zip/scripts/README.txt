script by daboynb
How to use:
These contain the script for Windows 10 and 11. For Windows 10 use create10.bat and Windows 11 use create11.bat